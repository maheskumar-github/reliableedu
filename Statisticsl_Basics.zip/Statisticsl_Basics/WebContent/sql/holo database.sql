\c;

create table IF  NOT EXISTS hl_user (tz_uid SERIAL primary key,name char(40),last_name char(40),email char(40) UNIQUE,password varchar(20),institute text,phone char(15));