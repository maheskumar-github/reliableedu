var valName = function () {
        $("#signup_name").css("border","none");
        var signup_name = $("#signup_name").val();
        pat = /^[a-zA-Z\-]{3,}$/;
        if (!pat.test(signup_name)) {
            $("#nameImg").show();
            $("#signup_name").css("border","1px solid red");
            $("#signup_name").attr("status", false);
        }
        else{
            $("#nameImg").hide();
            $("#signup_name").attr("status", true);
            $("#signup_name").css("border","1px solid #efefef");
        }
    }

var valLast = function () {
    $("#signup_last_name").css("border","none");
    var signup_last_name = $("#signup_last_name").val();
    pat = /^[a-zA-Z\-]{3,}$/;
    if (!pat.test(signup_last_name)) {
        $("#lastImg").show();
        $("#signup_last_name").css("border","1px solid red");
        $("#signup_last_name").attr("status", false);
    }
    else{
        $("#lastImg").hide();
        $("#signup_last_name").attr("status", true);
        $("#signup_last_name").css("border","1px solid #efefef");
    }
}

var valEmail = function () {
        $("#signup_email").css("border","none");
        var signup_email = $("#signup_email").val();
        pat = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
        if (!pat.test(signup_email)) {
            $("#mailImg").show();
            $("#signup_email").css("border","1px solid red");
            $("#signup_email").attr("status", false);
        }
        else{
            $("#mailImg").hide();
            $("#signup_email").attr("status", true);
            $("#signup_email").css("border","1px solid #efefef");
        }
    }
var valPass = function () {
        $("#signup_password").css("border","none");
        var signup_password = $("#signup_password").val();
        pat = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{5,}$/;
        if (!pat.test(signup_password)) {
            $("#passImg").show();
            $("#signup_password").css("border","1px solid red");
            $("#signup_password").attr("status", false);
        }
        else{
            $("#passImg").hide();
            $("#signup_password").attr("status", true);
            $("#signup_password").css("border","1px solid #efefef");
        }
    }

var valIns = function () {
        $("#signup_institute").css("border","none");
        var signup_institute = $("#signup_institute").val();
        if ((signup_institute.length) == 0) {
            $("#instituteImg").show();
            $("#signup_institute").css("border","1px solid red");
            $("#signup_institute").attr("status", false);
        }
        else{
            $("#instituteImg").hide();
            $("#signup_institute").attr("status", true);
            $("#signup_institute").css("border","1px solid #efefef");
        }
    }
var valPhone = function () {
        $("#signup_x_phone").css("border","none");
        var signup_x_phone = $("#signup_x_phone").val();
        pat = /^[0-9+]{13}$/;
        if (!pat.test(signup_x_phone)) {
            $("#x_phoneImg").show();
            $("#signup_x_phone").css("border","1px solid red");
            $("#signup_x_phone").attr("status", false);
        }
        else{
            $("#x_phoneImg").hide();
            $("#signup_x_phone").attr("status", true);
            $("#signup_x_phone").css("border","1px solid #efefef");
        }
    }
var valType = function () {
        $("#loc").css("border","none");
        var loc = $("#loc").val();
        pat = /^[a-zA-Z\-]{3,}$/;
        if (!pat.test(loc)) {
            $("#locImg").show();
            $("#loc").css("border","1px solid red");
            $("#loc").attr("status", false);
        }
        else{
            $("#locImg").hide();
            $("#loc").attr("status", true);
        }
    }

$(document).ready(function () {

    $("#signup_name").focus(function () {
        $("#nameImg").hide();
        $("#signup_name").css("border","1px solid #efefef");
    });
    
    $("#signup_last_name").focus(function () {
        $("#lastImg").hide();
        $("#signup_last_name").css("border","1px solid #efefef");
    });
    
    $("#signup_email").focus(function () {
        $("#mailImg").hide();
        $("#signup_email").css("border","1px solid #efefef");
    });

    
    $("#signup_password").focus(function () {
        $("#passImg").hide();
        $("#signup_password").css("border","1px solid #efefef");
    });

    $("#signup_institute").focus(function () {
        $("#instituteImg").hide();
        $("#signup_institute").css("border","1px solid #efefef");
    });

    
    $("#signup_x_phone").focus(function () {
        $("#x_phoneImg").hide();
        $("#signup_x_phone").css("border","1px solid #efefef");
        $("#signup_x_phone").val("+91");
    });

    
    $("#loc").focus(function () {
        $("#locImg").hide();
        $("#loc").css("border","1px solid #efefef");
    });
    
    $("#signup_button").click(function (evt) {
        evt.preventDefault();
        valName();
        valLast();
        valEmail ();
        valPass ();
        //valIns ();
        valPhone ();
        valType ();
        signup_data();
    });

});

var signup_data = function () {
    if($("#signup_name").attr("status") == "true" && $("#signup_last_name").attr("status") == "true" && $("#signup_email").attr("status") == "true" && $("#signup_password").attr("status") == "true" && $("#signup_institute").attr("status") == "true" && $("#signup_x_phone").attr("status") == "true" ){
    	var signup_name = $("#signup_name").val();
        var signup_last_name = $("#signup_last_name").val();
        var signup_email = $("#signup_email").val();
        var signup_password = $("#signup_password").val();
        var signup_institute = $("#signup_institute").val();
        var signup_x_phone = $("#signup_x_phone").val();
        
        var form = {'signup_name': signup_name , 'signup_last_name': signup_last_name , 'signup_email': signup_email , 'signup_password': signup_password , 'signup_institute': signup_institute , 'signup_x_phone': signup_x_phone}; 
        console.log(form);
        $.ajax({
        	url: 'SignupAction.action',
    		type: 'POST',
    		data: {'signup_name': signup_name , 'signup_last_name': signup_last_name , 'signup_email': signup_email , 'signup_password': signup_password , 'signup_institute': signup_institute , 'signup_x_phone': signup_x_phone},
    		success:function (form){
    			if(form.trim() == "success"){
    				console.log("ok");
    			}
    		},
          error: function(){
            console.log("failure");
          }
        });
//        $("#mainpageContainer").css("display","none");

    }
    else{
        console.log("not ok");
    }
}

var valsigninname = function () {
        $("#userSigninName").css("border","none");
        var signinname = $("#userSigninName").val();
        if ((signinname.length)==0) {
            $("#signinnameImg").show();
            $("#userSigninName").css("border","1px solid red");
            $("#userSigninName").attr("status", false);
        }
        else{
            $("#signinnameImg").hide();
            $("#userSigninName").attr("status", true);
        }
    }

var valsigninpass = function () {
        $("#userSigninPassword").css("border","none");
        var signinpass = $("#userSigninPassword").val();
        if ((signinpass.length)==0) {
            $("#signinpassImg").show();
            $("#userSigninPassword").css("border","1px solid red");
            $("#userSigninPassword").attr("status", false);
        }
        else{
            $("#signinpassImg").hide();
            $("#userSigninPassword").attr("status", true);
        }
    }
    
$(document).ready(function () {

    $("#userSigninName").focus(function () {
        $("#signinnameImg").hide();
        $("#userSigninName").css("border","1px solid #efefef");
    });

    
    $("#userSigninPassword").focus(function () {
        $("#signinpassImg").hide();
        $("#userSigninPassword").css("border","1px solid #efefef");
    });
    
    $("#signinsubButton").click(function (evt) {
        evt.preventDefault();
        valsigninname();
        valsigninpass();
        checksignin();
        
        });
});

var checksignin = function () {
    if($("#userSigninName").attr("status") == "true" && $("#userSigninPassword").attr("status") == "true" ){
        
        var form = $('#signinform').serializeArray();
        console.log(form);
        $.ajax({
            url: 'mykartsignin',
            type: 'POST',
            data: form,
            success: function (data){
                console.log("Ok");
                console.log(data);
                var dta = data.trim();
                console.log(dta);
                var signinuserdata = dta.split("\n");
                console.log(signinuserdata);
                if (signinuserdata[0] == "done") {
                    $("#signinform").submit();              
                    window.location.assign("mykarthome.html");
                    
                }
                else{
                    if (dta == "notok"){
                        $("#signinnameImg").show();
                        $("#userSigninName").css("border","1px solid red");
                        $("#userSigninName").attr("status", false);
                    	}
                    else{
                        $("#signinpassImg").show();
                        $("#userSigninPassword").css("border","1px solid red");
                        $("#userSigninPassword").attr("status", false);
                    	}
                }
            }
        });
        
    }
    else{
        console.log("Not ok");
    }
}
