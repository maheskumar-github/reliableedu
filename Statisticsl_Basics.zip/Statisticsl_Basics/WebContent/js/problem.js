function tool(e){
	var condition = ($(e).attr('tool')).trim();
	switch (condition) {
	    case "mean":
	    	changeUrl('#problem/mean')
	    	$("#rawdata").attr("tool","mean");
	    	$("#discretedata").attr("tool","mean");
	    	$("#continuousdata").attr("tool","mean");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	        break;
	    case "median":
	    	changeUrl('#problem/median')
	    	$("#rawdata").attr("tool","median");
	    	$("#discretedata").attr("tool","median");
	    	$("#continuousdata").attr("tool","median");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	        break;
	    case "mode":
	    	changeUrl('#problem/mode')
	    	$("#rawdata").attr("tool","mode");
	    	$("#discretedata").attr("tool","mode");
	    	$("#continuousdata").attr("tool","mode");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	        break;
	    case "hm":
	    	changeUrl('#problem/hm')
	    	$("#rawdata").attr("tool","hm");
	    	$("#discretedata").attr("tool","hm");
	    	$("#continuousdata").attr("tool","hm");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	        break;
	    case "gm":
	    	changeUrl('#problem/gm')
	    	$("#rawdata").attr("tool","gm");
	    	$("#discretedata").attr("tool","gm");
	    	$("#continuousdata").attr("tool","gm");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	        break;
	    case "range":
	    	changeUrl('#problem/range')
	    	$("#rawdata").attr("tool","range");
	    	$("#discretedata").attr("tool","range");
	    	$("#continuousdata").attr("tool","range");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	        break;
	    case "qd":
	    	changeUrl('#problem/qd')
	    	$("#rawdata").attr("tool","qd");
	    	$("#discretedata").attr("tool","qd");
	    	$("#continuousdata").attr("tool","qd");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	    	break;
	    case "md":
	    	changeUrl('#problem/md')
	    	$("#rawdata").attr("tool","md");
	    	$("#discretedata").attr("tool","md");
	    	$("#continuousdata").attr("tool","md");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	        break;
	    case "sd":
	    	changeUrl('#problem/sd')
	    	$("#rawdata").attr("tool","sd");
	    	$("#discretedata").attr("tool","sd");
	    	$("#continuousdata").attr("tool","sd");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	        break;
	    case "skp":
	    	changeUrl('#problem/skp')
	    	$("#rawdata").attr("tool","skp");
	    	$("#discretedata").attr("tool","skp");
	    	$("#continuousdata").attr("tool","skp");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	        break;
	    case "skbow":
	    	changeUrl('#problem/skbow')
	    	$("#rawdata").attr("tool","skbow");
	    	$("#discretedata").attr("tool","skbow");
	    	$("#continuousdata").attr("tool","skbow");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	        break;
	    case "kurtosis":
	    	changeUrl('#problem/kurtosis')
	    	$("#rawdata").attr("tool","kurtosis");
	    	$("#discretedata").attr("tool","kurtosis");
	    	$("#continuousdata").attr("tool","kurtosis");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	        break;
	    case "karl_rel":
	    	changeUrl('#problem/karl_rel')
	    	$("#rawdata").attr("tool","karl_rel");
	    	$("#discretedata").attr("tool","karl_rel");
	    	$("#continuousdata").attr("tool","karl_rel");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	        break;
	    case "reg":
	    	changeUrl('#problem/reg')
	    	$("#rawdata").attr("tool","reg");
	    	$("#discretedata").attr("tool","reg");
	    	$("#continuousdata").attr("tool","reg");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	    	break;
	    case "spear_rel":
	    	changeUrl('#problem/spear_rel')
	    	$("#rawdata").attr("tool","spear_rel");
	    	$("#discretedata").attr("tool","spear_rel");
	    	$("#continuousdata").attr("tool","spear_rel");
	    	$("#container").css("display","block");
	    	$("#container1").css("display","none");
	    	$("#container2").css("display","none");
	    	$("#container3").css("display","none");
	}
}

function data_type(e){
	var datatype = ($(e).attr('id')).trim();
	var tool = ($(e).attr('tool')).trim();
	$("#value").html('');
	$("#container").css("display","none");
	$("#container1").css("display","block");
	$("#container2").css("display","none");
	$("#container3").css("display","none");
	$("#no_of_data_btn").attr("tool",tool);
	$("#no_of_data_btn").attr("data-type",datatype);
	changeUrl('#problems/'+tool+'/'+datatype);
}

function no_of_data(e){
	var no_of_value = ($("#value").html()).trim();
	var datatype = ($(e).attr('data-type')).trim();
	var tool = ($(e).attr('tool')).trim();
	changeUrl('#problems/'+tool+'/'+datatype+'/no_of_data');
	$("#container1").css("display","none");
	$("#container").css("display","none");
	$("#container3").css("display","none");
	var content = '<table style="margin-left: auto; margin-right: auto;">'
	if(datatype == "rawdata"){
		content += '<tr id="x">'
		for(i=0; i<parseInt(no_of_value); i++){
		    content += '<td id="x'+i+'" style="text-align: center; border: 1px solid #eee; height:75px; font-size:50px;position: relative;top: 40px; width:50px;" contenteditable></td>';
		}
		content += '</tr>'
	}else if(datatype == "discretedata"){
		content += '<tr id="x">'
//		content += '<td>X</td>'
		for(i=0; i<parseInt(no_of_value); i++){
		    content += '<td id="x'+i+'" style="text-align: center; border: 1px solid #eee; height:65px; font-size:50px;position: relative;top: 40px; width:50px;" contenteditable></td>';
		}
		content += '</tr>'
		content += '<tr id="y">'
		for(i=0; i<parseInt(no_of_value); i++){
		    content += '<td id="y'+i+'" style="text-align: center; border: 1px solid #eee; height:65px; font-size:50px;position: relative;top: 40px; width:50px;" contenteditable></td>';
		}
		content += '</tr>'
	}else{
		content += '<tr id="x">'
			for(i=0; i<parseInt(no_of_value); i++){
			    content += '<td id="x'+i+'" style="border: 1px solid #eee; height:65px; font-size:50px;position: relative;top: 40px; width:50px; text-align: center;" contenteditable></td>';
			}
			content += '</tr>'
			content += '<tr id="y">'
			for(i=0; i<parseInt(no_of_value); i++){
			    content += '<td id="y'+i+'" style="text-align: center; border: 1px solid #eee; height:65px; font-size:50px;position: relative;top: 40px; width:50px;" contenteditable></td>';
			}
			content += '</tr>'
		}
	
	content += "</table>"
	content += '<div style="margin-top: 100px; position: absolute;left: 45%;"><a><button tool="'+tool+'" data-type="'+datatype+'" onclick="getAnswer(this)" class="btn pri tc" style="min-width:180px;" id="getanswer">Get Answer</button></a></div>'
	$("#container2").empty();
	$('#container2').append(content);
	$("#container2").css("display","block");
}

function getAnswer(e){
	var datatype = ($(e).attr('data-type')).trim();
	var tool = ($(e).attr('tool')).trim();
	var count = $('#x').children('td').length;
	if(datatype == "rawdata"){
		var x = "";
	    for(i=0; i<parseInt(count); i++){
	    	x += $('#x'+i).html()+",";
	    }
	    console.log(x);
	    $.ajax({
	    	  type: "POST",
	    	  url: "Problem.action",
	    	  data: {"x" : x,"datatype" : datatype,"tool" : tool},
	    	  success: function(data){
	    		  $("#container").css("display","none");
	    			$("#container1").css("display","none");
	    			$("#container2").css("display","none");
	    		  $("#container3").css("display","block");
	    		  $("#container3").empty();
	    		  $("#container3").html(data);
	    	  }
	    	});
	}
	else if(datatype == "discretedata" || datatype == "continuousdata"){
		var x = "";
		var y = "";
	    for(i=0; i<parseInt(count); i++){
	    	x += $('#x'+i).html()+",";
	    	y += $('#y'+i).html()+",";
	    }
	    console.log(x);
	    console.log(y);
	    $.ajax({
	    	  type: "POST",
	    	  url: "Problem.action",
	    	  data: {"x" : x,"y" : y,"datatype" : datatype,"tool" : tool},
	    	  success: function(data){
	    		  $("#container").css("display","none");
	    			$("#container1").css("display","none");
	    			$("#container2").css("display","none");
	    		  $("#container3").css("display","block");
	    		  $("#container3").empty();
	    		  $("#container3").html(data);
	    	  }
	    	});
	}
}
