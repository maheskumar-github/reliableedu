/**
 * 
 */
package org.descripitive.statisticsnewui.signup;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

//import javax.servlet.http.HttpServletRequest;


import com.opensymphony.xwork2.ActionSupport;

/**
 * @author maheskumar
 *
 */
public class SignupAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	private String signup_name,signup_last_name,signup_email,signup_password,signup_institute,signup_x_phone;
	PrintStream out = System.out;
	
	/*HttpServletRequest request;
	email = request.getParameter;*/
	
	
	public String execute(){  
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String dbURL1 = "jdbc:mysql://localhost:3306/sonoo\",\"root\",\"root";
	        Connection conn = DriverManager.getConnection(dbURL1);
			Statement statement = conn.createStatement();
			String query = "INSERT INTO hl_user(name,last_name,email,password,institute,phone) VALUES ('"+getSignup_name()+"','"+getSignup_last_name()+"','"+getSignup_email()+"','"+getSignup_password()+"','"+getSignup_institute()+"','"+getSignup_x_phone()+"');";
			statement.executeUpdate(query);
			statement.close();
			conn.close();
			return "success";
		}
		catch (Exception e){
			addActionMessage("Driver not loaded");	
			return "error";

		}
		}

	public String getSignup_password() {
		return signup_password;
	}

	public void setSignup_password(String signup_password) {
		this.signup_password = signup_password;
	}

	public String getSignup_email() {
		return signup_email;
	}

	public void setSignup_email(String signup_email) {
		this.signup_email = signup_email;
	}

	public String getSignup_name() {
		return signup_name;
	}

	public void setSignup_name(String signup_name) {
		this.signup_name = signup_name;
	}

	public String getSignup_last_name() {
		return signup_last_name;
	}

	public void setSignup_last_name(String signup_last_name) {
		this.signup_last_name = signup_last_name;
	}

	public String getSignup_institute() {
		return signup_institute;
	}

	public void setSignup_institute(String signup_institute) {
		this.signup_institute = signup_institute;
	}

	public String getSignup_x_phone() {
		return signup_x_phone;
	}

	public void setSignup_x_phone(String signup_x_phone) {
		this.signup_x_phone = signup_x_phone;
	}
	
}
