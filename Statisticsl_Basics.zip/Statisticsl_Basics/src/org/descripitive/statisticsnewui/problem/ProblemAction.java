package org.descripitive.statisticsnewui.problem;

import java.util.*;

import com.opensymphony.xwork2.ActionSupport;
public class ProblemAction extends ActionSupport  {
	private static final long serialVersionUID = 1L;
	private String datatype,tool,x,y,medianstr1="",odd="",medianstr="",medianstr2="",g2="",g3="",g4="",g5="",g6="",l="",f1="",f0="",f2="",i="",z="";
	private double sum,answer,mediananswer,sumfre,xsum,x2sum,y2sum,q1;
	private int count,medianpos;
	private List<Double> xlist,fxlist,ylist,loglist;
	private String[] sortedarray;
	private String[] g0a = new String[50];
	private String[] g1a = new String[50];
	private String[] g2a = new String[50];
	private String[] g3a = new String[50];
	private String[] g4a = new String[50];
	private String[] g5a = new String[50];
	private String[] g6a = new String[50];
	private String[] g7a = new String[50];
	private double banswer;
	private int bmedianpos;
	private String bmedianstr;
	private String bmedianstr1;
	private double bmediananswer;
	private String bodd;
	
	public String execute()
	{
		xlist = new ArrayList<Double>();
		String[] stringArray = x.split(",");
		
		if(tool.equals("mean")) {
			if(datatype.equals("rawdata")) {
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							sum += Double.parseDouble(numberAsString);
							count++;
						
					}
				try {answer = sum / count;}catch(Exception e) {System.out.println(e);}
			}else if(datatype.equals("discretedata")) {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sumfre += Double.parseDouble(ynumberAsString);
							sum += Double.parseDouble(ynumberAsString)*Double.parseDouble(numberAsString);
							medianstr += String.valueOf(Double.parseDouble(ynumberAsString)*Double.parseDouble(numberAsString))+",";
							count++;
						
					}
				try {answer = sum / sumfre;}catch(Exception e) {System.out.println(e);}
			}else {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] temp = numberAsString.split("-");
						medianstr1 += String.valueOf((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)+",";
							//xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sumfre += Double.parseDouble(ynumberAsString);
							sum += Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
							medianstr += String.valueOf(Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2))+",";
							count++;
						
					}
				try {answer = sum / sumfre;}catch(Exception e) {System.out.println(e);}
			}
		}else if(tool.equals("median")) {
			if(datatype.equals("rawdata")) {
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							count++;
						
					}
				sum = count+1;
				sortedarray = x.split(",");
				sortedarray = getSortedarray(sortedarray);
			    try {answer = sum / 2;}catch(Exception e) {System.out.println(e);}
			    if((sum%2)!= 0) {
			    	medianpos = (int) ((answer-0.5)+(answer+0.5))/2;
			    	medianstr = "("+String.valueOf(answer-0.5)+"th value+"+String.valueOf(answer+0.5)+"th value)/2";
			    	medianstr1 = "("+String.valueOf(sortedarray[(int) (answer-0.5)-1]+"+"+String.valueOf(sortedarray[(int) (answer+0.5)-1]))+")/2";
			    	mediananswer = ((Double.parseDouble(sortedarray[(int) ((answer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((answer+0.5)-1)]))/2);
			    	odd = "yes";
			    }else {
			    	mediananswer = Integer.parseInt(sortedarray[(int) answer-1]);
			    	odd = "no";
			    }
			}else if(datatype.equals("discretedata")) {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				// medianstr += String.valueOf(Double.parseDouble(ystringArray[0]));
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							medianstr += String.valueOf(Double.parseDouble(ynumberAsString)+sumfre)+",";
							sumfre += Double.parseDouble(ynumberAsString);
							count++;
						
					}
				sum = sumfre+1;
				/*sortedarray = x.split(",");
				sortedarray = getSortedarray(sortedarray);*/
			    try {answer = sum / 2;}catch(Exception e) {System.out.println(e);}
			    medianstr1 += String.valueOf(answer);
			    /*if((sum%2)!= 0) {
			    	medianpos = (int) ((answer-0.5)+(answer+0.5))/2;
			    	medianstr = "("+String.valueOf(answer-0.5)+"th value+"+String.valueOf(answer+0.5)+"th value)/2";
			    	medianstr1 = "("+String.valueOf(sortedarray[(int) (answer-0.5)-1]+"+"+String.valueOf(sortedarray[(int) (answer+0.5)-1]))+")/2";
			    	mediananswer = ((Double.parseDouble(sortedarray[(int) ((answer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((answer+0.5)-1)]))/2);
			    	odd = "yes";
			    }else {
			    	mediananswer = Integer.parseInt(sortedarray[(int) answer-1]);
			    	odd = "no";
			    }*/
			}else {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] temp = numberAsString.split("-");
						medianstr1 += String.valueOf((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)+",";
							//xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sum += Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
							medianstr += String.valueOf(Double.parseDouble(ynumberAsString)+sumfre)+",";
							sumfre += Double.parseDouble(ynumberAsString);
							count++;
						
					}
				try {answer = sumfre / 2;}catch(Exception e) {System.out.println(e);}
				medianstr2 += String.valueOf(answer);
			}
		}else if(tool.equals("mode")) {
			if(datatype.equals("rawdata")) {
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							sum += Double.parseDouble(numberAsString);
							count++;
						
					}
				try {answer = sum / count;}catch(Exception e) {System.out.println(e);}
				medianstr = getRawmode(stringArray);
			}else if(datatype.equals("discretedata")) {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				int index1 = 0;
				double temp1 = 0.0;
				String[] ystringArray = y.split(",");
				/*g0a = new String[stringArray.length+2];
				g1a = new String[stringArray.length+2];
				g2a = new String[stringArray.length+2];
				g3a = new String[stringArray.length+2];
				g4a = new String[stringArray.length+2];
				g5a = new String[stringArray.length+2];
				g6a = new String[stringArray.length+2];
				g7a = new String[stringArray.length+2];
				for (int i = 0; i < stringArray.length+2; i++) {
					g0a[i] = "0";
					g1a[i] = "0";
					g2a[i] = "0";
					g3a[i] = "0";
					g4a[i] = "0";
					g5a[i] = "0";
					g6a[i] = "0";
					g7a[i] = "0";
						
					}*/
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sumfre += Double.parseDouble(ynumberAsString);
							sum += Double.parseDouble(ynumberAsString)*Double.parseDouble(numberAsString);
							medianstr += String.valueOf(Double.parseDouble(ynumberAsString)*Double.parseDouble(numberAsString))+",";
							count++;
							if(temp1 < Double.parseDouble(ynumberAsString)) {
								temp1 = Double.parseDouble(ynumberAsString);
								index1 = i;
							}
						
					}
				/*g0a [0] = "Col.No";
				g1a [0] = "1";
				g2a [0] = "2";
				g3a [0] = "3";
				g4a [0] = "4";
				g5a [0] = "5";
				g6a [0] = "6";
				g7a [0] = "Total";
				for (int j = 0; j < stringArray.length; j++) {
					String numberAsString = stringArray[j];
					System.out.println(numberAsString);
					String ynumberAsString = ystringArray[j];
					g0a [j+1] = numberAsString;
					g1a [j+1] = "0";
					g2a [j+1] = "0";
					g3a [j+1] = "0";
					g4a [j+1] = "0";
					g5a [j+1] = "0";
					g6a [j+1] = "0";
					if((Double.valueOf(ystringArray[index1]) == Double.valueOf(ynumberAsString) && j != index1) || Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+1)|| Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+2)) {
						odd = "yes";
						
					}
					System.out.println(ystringArray[index1]+" == "+ ynumberAsString +" && "+String.valueOf(j) +"!="+ String.valueOf(index1)+" ||"+ystringArray[index1]+" == "+String.valueOf(Double.valueOf(ynumberAsString)+1)+"|| "+ystringArray[index1]+" == "+String.valueOf(Double.valueOf(ynumberAsString)+2));
					System.out.println((Double.valueOf(ystringArray[index1]) == Double.valueOf(ynumberAsString) && j != index1) || Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+1)|| Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+2));
				}
				if(odd.equals("yes")) {
					
					g1a[index1+1] = "1";
					g1a[ystringArray.length+1] = "1";
					int i0 = 0; int i1 = 1; int i2 = 2;
					double maxvalue = 0;
					int tempi0 = 0;int tempi1 = 0;int tempi2 = 0;
					for (int i = 0; i < (ystringArray.length-ystringArray.length%2)/2; i++) {
						g2 += ystringArray[i0]+"+"+ystringArray[i1]+"="+String.valueOf(Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1]))+",";
						
						
						if(maxvalue < Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1])) {
							tempi0 = i0;tempi1 = i1;
						}
						i0 += 2;i1 += 2;
						if(i == ((ystringArray.length-ystringArray.length%2)/2)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1));
							g2a[tempi0-3] = "1";
							g2a[tempi1-3] = "1";
							i0 = 0; i1 = 1;
						}
					}
					for (int i = 0; i < ((ystringArray.length)-ystringArray.length%2)/2; i++) {
						g3 += ystringArray[i0+1]+"+"+ystringArray[i1+1]+"="+String.valueOf(Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1]))+",";
						
						if(maxvalue < Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1])) {
							tempi0 = i0+1;tempi1 = i1+1;
						}
						i0 += 2;i1 += 2;
						if(i == (((ystringArray.length)-ystringArray.length%2)/2)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1));
							g3a[tempi0-3] = "1";
							g3a[tempi1-3] = "1";
							i0 = 0; i1 = 1;
						}
					}
					System.out.println(g2+" "+g3);
					System.out.println(String.valueOf(i0)+" "+String.valueOf(i1)+" "+String.valueOf(i2));
					for (int i = 0; i < (ystringArray.length-ystringArray.length%3)/3; i++) {
						System.out.println(String.valueOf(i0)+" "+String.valueOf(i1)+" "+String.valueOf(i2));
						g4 += ystringArray[i0]+"+"+ystringArray[i1]+"+"+ystringArray[i2]+"="+String.valueOf(Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1])+Double.valueOf(ystringArray[i2]))+",";
						
						if(maxvalue < Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1])+Double.valueOf(ystringArray[i2])) {
							tempi0 = i0;tempi1 = i1;tempi2 = i2;
						}
						i0 += 3;i1 += 3;i2 += 3;
						if(i == ((ystringArray.length-ystringArray.length%3)/3)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1)+"   "+String.valueOf(tempi2+1));
							g4a[tempi0-2] = "1";
							g4a[tempi1-2] = "1";
							g4a[tempi2-2] = "1";
							i0 = 0; i1 = 1; i2 = 2;
						}
					}
					for (int i = 0; i < ((ystringArray.length-1)-ystringArray.length%3)/3; i++) {
						g5 += ystringArray[i0+1]+"+"+ystringArray[i1+1]+"+"+ystringArray[i2+1]+"="+String.valueOf(Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1])+Double.valueOf(ystringArray[i2+1]))+",";
						if(maxvalue < Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1])+Double.valueOf(ystringArray[i2+1])) {
							tempi0 = i0+1;tempi1 = i1+1;tempi2 = i2+1;
						}
						i0 += 3;i1 += 3;i2 += 3;
						if(i == (((ystringArray.length-1)-ystringArray.length%3)/3)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1)+"   "+String.valueOf(tempi2+1));
							g5a[tempi0-2] = "1";
							g5a[tempi1-2] = "1";
							g5a[tempi2-2] = "1";
							i0 = 0; i1 = 1; i2 = 2;
						}
					}
					for (int i = 0; i < ((ystringArray.length-1)-ystringArray.length%3)/3; i++) {
						g6 += ystringArray[i0+2]+"+"+ystringArray[i1+2]+"+"+ystringArray[i2+2]+"="+String.valueOf(Double.valueOf(ystringArray[i0+2])+Double.valueOf(ystringArray[i1+2])+Double.valueOf(ystringArray[i2+2]))+",";
						
						if(maxvalue < Double.valueOf(ystringArray[i0+2])+Double.valueOf(ystringArray[i1+2])+Double.valueOf(ystringArray[i2+2])) {
							tempi0 = i0+2;tempi1 = i1+2;tempi2 = i2+2;
						}
						i0 += 3;i1 += 3;i2 += 3;
						if(i == (((stringArray.length-1)-stringArray.length%3)/3)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1)+"   "+String.valueOf(tempi2+1));
							g6a[tempi0-2] = "1";
							g6a[tempi1-2] = "1";
							g6a[tempi2-2] = "1";
							
						}
					}
					System.out.println(g4+" "+g5+" "+g6);
					g2a[ystringArray.length+1] = "2";
					g3a[ystringArray.length+1] = "2";
					g4a[ystringArray.length+1] = "3";
					g5a[ystringArray.length+1] = "3";
					g6a[ystringArray.length+1] = "3";
					for(int i=0; i < ystringArray.length; i++) {
						g7a[i+1] = String.valueOf(Double.valueOf(g1a[i+1])+Double.valueOf(g2a[i+1])+Double.valueOf(g3a[i+1])+Double.valueOf(g4a[i+1])+Double.valueOf(g5a[i+1])+Double.valueOf(g6a[i+1]));
						
					}
					g7a[ystringArray.length+1] = "14";
					g0a[ystringArray.length+1] = "Total";
				}
				double temp2 = 0.0;
				for (int i = 0; i < stringArray.length; i++) {
				      String g7astring = g7a[i+1];
							
							if(temp2 < Double.parseDouble(g7astring)) {
								temp2 = Double.parseDouble(g7astring);
								index1 = i;
							}
						
					}*/
				System.out.println(String.valueOf(index1));
				try {answer = 9%2;}catch(Exception e) {System.out.println(e);}
				medianstr = stringArray[index1];
			}else {
				
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				int index1 = 0;
				//String temp = "";
				double temp1 = 0.0;
				String[] ystringArray = y.split(",");
				/*g0a = new String[stringArray.length+2];
				g1a = new String[stringArray.length+2];
				g2a = new String[stringArray.length+2];
				g3a = new String[stringArray.length+2];
				g4a = new String[stringArray.length+2];
				g5a = new String[stringArray.length+2];
				g6a = new String[stringArray.length+2];
				g7a = new String[stringArray.length+2];
				for (int i = 0; i < stringArray.length+2; i++) {
					g0a[i] = "0";
					g1a[i] = "0";
					g2a[i] = "0";
					g3a[i] = "0";
					g4a[i] = "0";
					g5a[i] = "0";
					g6a[i] = "0";
					g7a[i] = "0";
						
					}*/
				for (int i = 0; i < stringArray.length; i++) {
					String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] temp = numberAsString.split("-");
						medianstr1 += String.valueOf((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)+",";
							//xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sumfre += Double.parseDouble(ynumberAsString);
							sum += Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
							medianstr += String.valueOf(Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2))+",";
							count++;
							if(temp1 < Double.parseDouble(ynumberAsString)) {
								temp1 = Double.parseDouble(ynumberAsString);
								index1 = i;
							}
						
					}
				/*g0a [0] = "Col.No";
				g1a [0] = "1";
				g2a [0] = "2";
				g3a [0] = "3";
				g4a [0] = "4";
				g5a [0] = "5";
				g6a [0] = "6";
				g7a [0] = "Total";
				for (int j = 0; j < stringArray.length; j++) {
					String numberAsString = stringArray[j];
					System.out.println(numberAsString);
					String ynumberAsString = ystringArray[j];
					g0a [j+1] = numberAsString;
					g1a [j+1] = "0";
					g2a [j+1] = "0";
					g3a [j+1] = "0";
					g4a [j+1] = "0";
					g5a [j+1] = "0";
					g6a [j+1] = "0";
					if((Double.valueOf(ystringArray[index1]) == Double.valueOf(ynumberAsString) && j != index1) || Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+1)|| Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+2)) {
						odd = "yes";
						
					}
					System.out.println(ystringArray[index1]+" == "+ ynumberAsString +" && "+String.valueOf(j) +"!="+ String.valueOf(index1)+" ||"+ystringArray[index1]+" == "+String.valueOf(Double.valueOf(ynumberAsString)+1)+"|| "+ystringArray[index1]+" == "+String.valueOf(Double.valueOf(ynumberAsString)+2));
					System.out.println((Double.valueOf(ystringArray[index1]) == Double.valueOf(ynumberAsString) && j != index1) || Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+1)|| Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+2));
				}
				if(odd.equals("yes")) {
					
					g1a[index1+1] = "1";
					g1a[ystringArray.length+1] = "1";
					int i0 = 0; int i1 = 1; int i2 = 2;
					double maxvalue = 0;
					int tempi0 = 0;int tempi1 = 0;int tempi2 = 0;
					for (int i = 0; i < (ystringArray.length-ystringArray.length%2)/2; i++) {
						g2 += ystringArray[i0]+"+"+ystringArray[i1]+"="+String.valueOf(Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1]))+",";
						
						
						if(maxvalue < Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1])) {
							tempi0 = i0;tempi1 = i1;
						}
						i0 += 2;i1 += 2;
						if(i == ((ystringArray.length-ystringArray.length%2)/2)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1));
							g2a[tempi0-3] = "1";
							g2a[tempi1-3] = "1";
							i0 = 0; i1 = 1;
						}
					}
					for (int i = 0; i < ((ystringArray.length)-ystringArray.length%2)/2; i++) {
						g3 += ystringArray[i0+1]+"+"+ystringArray[i1+1]+"="+String.valueOf(Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1]))+",";
						
						if(maxvalue < Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1])) {
							tempi0 = i0+1;tempi1 = i1+1;
						}
						i0 += 2;i1 += 2;
						if(i == (((ystringArray.length)-ystringArray.length%2)/2)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1));
							g3a[tempi0-5] = "1";
							g3a[tempi1-5] = "1";
							i0 = 0; i1 = 1;
						}
					}
					System.out.println(g2+" "+g3);
					System.out.println(String.valueOf(i0)+" "+String.valueOf(i1)+" "+String.valueOf(i2));
					for (int i = 0; i < (ystringArray.length-ystringArray.length%3)/3; i++) {
						System.out.println(String.valueOf(i0)+" "+String.valueOf(i1)+" "+String.valueOf(i2));
						g4 += ystringArray[i0]+"+"+ystringArray[i1]+"+"+ystringArray[i2]+"="+String.valueOf(Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1])+Double.valueOf(ystringArray[i2]))+",";
						
						if(maxvalue < Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1])+Double.valueOf(ystringArray[i2])) {
							tempi0 = i0;tempi1 = i1;tempi2 = i2;
						}
						i0 += 3;i1 += 3;i2 += 3;
						if(i == ((ystringArray.length-ystringArray.length%3)/3)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1)+"   "+String.valueOf(tempi2+1));
							g4a[tempi0-5] = "1";
							g4a[tempi1-5] = "1";
							g4a[tempi2-5] = "1";
							i0 = 0; i1 = 1; i2 = 2;
						}
					}
					for (int i = 0; i < ((ystringArray.length-1)-ystringArray.length%3)/3; i++) {
						g5 += ystringArray[i0+1]+"+"+ystringArray[i1+1]+"+"+ystringArray[i2+1]+"="+String.valueOf(Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1])+Double.valueOf(ystringArray[i2+1]))+",";
						if(maxvalue < Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1])+Double.valueOf(ystringArray[i2+1])) {
							tempi0 = i0+1;tempi1 = i1+1;tempi2 = i2+1;
						}
						i0 += 3;i1 += 3;i2 += 3;
						if(i == (((ystringArray.length-1)-ystringArray.length%3)/3)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1)+"   "+String.valueOf(tempi2+1));
							g5a[tempi0-2] = "1";
							g5a[tempi1-2] = "1";
							g5a[tempi2-2] = "1";
							i0 = 0; i1 = 1; i2 = 2;
						}
					}
					for (int i = 0; i < ((ystringArray.length-1)-ystringArray.length%3)/3; i++) {
						g6 += ystringArray[i0+2]+"+"+ystringArray[i1+2]+"+"+ystringArray[i2+2]+"="+String.valueOf(Double.valueOf(ystringArray[i0+2])+Double.valueOf(ystringArray[i1+2])+Double.valueOf(ystringArray[i2+2]))+",";
						
						if(maxvalue < Double.valueOf(ystringArray[i0+2])+Double.valueOf(ystringArray[i1+2])+Double.valueOf(ystringArray[i2+2])) {
							tempi0 = i0+2;tempi1 = i1+2;tempi2 = i2+2;
						}
						i0 += 3;i1 += 3;i2 += 3;
						if(i == (((stringArray.length-1)-stringArray.length%3)/3)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1)+"   "+String.valueOf(tempi2+1));
							g6a[tempi0-2] = "1";
							g6a[tempi1-2] = "1";
							g6a[tempi2-2] = "1";
							
						}
					}
					System.out.println(g4+" "+g5+" "+g6);
					g2a[ystringArray.length+1] = "2";
					g3a[ystringArray.length+1] = "2";
					g4a[ystringArray.length+1] = "3";
					g5a[ystringArray.length+1] = "3";
					g6a[ystringArray.length+1] = "3";
					for(int i=0; i < ystringArray.length; i++) {
						g7a[i+1] = String.valueOf(Double.valueOf(g1a[i+1])+Double.valueOf(g2a[i+1])+Double.valueOf(g3a[i+1])+Double.valueOf(g4a[i+1])+Double.valueOf(g5a[i+1])+Double.valueOf(g6a[i+1]));
						
					}
					g7a[ystringArray.length+1] = "14";
					g0a[ystringArray.length+1] = "Total";
				}
				double temp2 = 0.0;
				for (int i = 0; i < stringArray.length; i++) {
				      String g7astring = g7a[i+1];
							
							if(temp2 < Double.parseDouble(g7astring)) {
								temp2 = Double.parseDouble(g7astring);
								index1 = i;
							}
						
					}
				System.out.println(String.valueOf(index1));*/
				try {answer = 9%2;}catch(Exception e) {System.out.println(e);}
				medianstr = stringArray[index1];
				String[] l1 = medianstr.split("-");
				l = l1[0];
				f1 = ystringArray[index1];
				f0 = ystringArray[index1-1];
				f2 = ystringArray[index1+1];
				i = String.valueOf(Integer.valueOf(l1[1])-Integer.valueOf(l1[0]));
				
				/*ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] temp = numberAsString.split("-");
						medianstr1 += String.valueOf((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)+",";
							//xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sumfre += Double.parseDouble(ynumberAsString);
							sum += Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
							medianstr += String.valueOf(Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2))+",";
							count++;
						
					}
				try {answer = sum / sumfre;}catch(Exception e) {System.out.println(e);}*/
			}
		}else if(tool.equals("gm")) {
			if(datatype.equals("rawdata")) {
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      xlist.add(Double.parseDouble(numberAsString));
							count++;
							medianstr += String.valueOf(Math.log10(Double.parseDouble(numberAsString)))+",";
							sum += Math.log10(Double.parseDouble(numberAsString));
					}
				try {mediananswer = sum / count;}catch(Exception e) {System.out.println(e);}
				answer = Math.pow(10, mediananswer);
			}else if(datatype.equals("discretedata")) {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sumfre += Double.parseDouble(ynumberAsString);
							medianstr += String.valueOf(Math.log10(Double.parseDouble(numberAsString)))+",";
							medianstr1 += String.valueOf(Math.log10(Double.parseDouble(numberAsString))*Double.parseDouble(ynumberAsString))+",";
							sum += Math.log10(Double.parseDouble(numberAsString))*Double.parseDouble(ynumberAsString);
							count++;
						
					}
				try {mediananswer = sum / sumfre;}catch(Exception e) {System.out.println(e);}
				answer = Math.pow(10, mediananswer);
			}else {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] temp = numberAsString.split("-");
						odd += String.valueOf((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)+",";
							//xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sumfre += Double.parseDouble(ynumberAsString);
							medianstr += String.valueOf(Math.log10(((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)))+",";
							medianstr1 += String.valueOf((Math.log10(((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)))*Double.parseDouble(ynumberAsString))+",";
							sum += (Math.log10(((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)))*Double.parseDouble(ynumberAsString);
							count++;
						
					}
				try {mediananswer = sum / sumfre;}catch(Exception e) {System.out.println(e);}
				answer = Math.pow(10, mediananswer);
			}
		}else if(tool.equals("hm")) {
			if(datatype.equals("rawdata")) {
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      xlist.add(Double.parseDouble(numberAsString));
							count++;
							medianstr += String.valueOf(1/(Double.parseDouble(numberAsString)))+",";
							sum += 1/(Double.parseDouble(numberAsString));
					}
				try {answer = count / sum;}catch(Exception e) {System.out.println(e);}
			}else if(datatype.equals("discretedata")) {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sumfre += Double.parseDouble(ynumberAsString);
							medianstr += String.valueOf(1/(Double.parseDouble(numberAsString)))+",";
							medianstr1 += String.valueOf((1/(Double.parseDouble(numberAsString)))*Double.parseDouble(ynumberAsString))+",";
							sum += (1/(Double.parseDouble(numberAsString)))*Double.parseDouble(ynumberAsString);
							count++;
						
					}
				try {mediananswer = sumfre / sum;}catch(Exception e) {System.out.println(e);}
				answer = mediananswer;
			}else {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] temp = numberAsString.split("-");
						odd += String.valueOf((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)+",";
							//xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sumfre += Double.parseDouble(ynumberAsString);
							medianstr += String.valueOf(1/(((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)))+",";
							medianstr1 += String.valueOf((1/(((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)))*Double.parseDouble(ynumberAsString))+",";
							sum += ((1/((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)))*Double.parseDouble(ynumberAsString);
							count++;
						
					}
				try {mediananswer = sumfre / sum;}catch(Exception e) {System.out.println(e);}
				answer = mediananswer;
			}
		}else if(tool.equals("range")) {
			for (int i = 0; i < stringArray.length; i++) {
			      String numberAsString = stringArray[i];
						xlist.add(Double.parseDouble(numberAsString));
				}
		}else if(tool.equals("qd")) {
			if(datatype.equals("rawdata")) {
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							count++;
						
					}
				sum = count+1;
				sortedarray = x.split(",");
				sortedarray = getSortedarray(sortedarray);
			    try {answer = sum / 4;}catch(Exception e) {System.out.println(e);}
			    if((sum%4)!= 0) {
			    	medianstr = "("+String.valueOf(answer-0.5)+"th value+"+String.valueOf(answer+0.5)+"th value)/4";
			    	medianstr1 = "("+String.valueOf(sortedarray[(int) (answer-0.5)-1]+"+"+String.valueOf(sortedarray[(int) (answer+0.5)-1]))+")/2";
			    	g2 = "("+String.valueOf(3*answer-0.5)+"th value+"+String.valueOf(3*answer+0.5)+"th value)/4";
			    	g3 = "("+String.valueOf(sortedarray[(int) (3*answer-0.5)-1]+"+"+String.valueOf(sortedarray[(int) (3*answer+0.5)-1]))+")/2";
			    	mediananswer = ((Double.parseDouble(sortedarray[(int) ((answer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((answer+0.5)-1)]))/2);
			    	f1 = String.valueOf(3*(Double.parseDouble(sortedarray[(int) ((3*answer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((3*answer+0.5)-1)]))/2);
			    	medianpos = (int) (Double.parseDouble(sortedarray[(int) ((answer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((answer+0.5)-1)]));
			    	q1 = (int) (Double.parseDouble(sortedarray[(int) ((3*answer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((3*answer+0.5)-1)]));
			    	odd = "yes";
			    }else {
			    	mediananswer = Integer.parseInt(sortedarray[(int) answer-1]);
			    	f1 = String.valueOf(Integer.parseInt(sortedarray[(int) (3*answer)-1]));
			    	odd = "no";
			    }
			}else if(datatype.equals("discretedata")) {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				// medianstr += String.valueOf(Double.parseDouble(ystringArray[0]));
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							medianstr += String.valueOf(Double.parseDouble(ynumberAsString)+sumfre)+",";
							sumfre += Double.parseDouble(ynumberAsString);
							count++;
						
					}
				sum = sumfre+1;
				/*sortedarray = x.split(",");
				sortedarray = getSortedarray(sortedarray);*/
			    try {answer = sum / 4;}catch(Exception e) {System.out.println(e);}
			    medianstr1 += String.valueOf(answer);
			    /*if((sum%2)!= 0) {
			    	medianpos = (int) ((answer-0.5)+(answer+0.5))/2;
			    	medianstr = "("+String.valueOf(answer-0.5)+"th value+"+String.valueOf(answer+0.5)+"th value)/2";
			    	medianstr1 = "("+String.valueOf(sortedarray[(int) (answer-0.5)-1]+"+"+String.valueOf(sortedarray[(int) (answer+0.5)-1]))+")/2";
			    	mediananswer = ((Double.parseDouble(sortedarray[(int) ((answer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((answer+0.5)-1)]))/2);
			    	odd = "yes";
			    }else {
			    	mediananswer = Integer.parseInt(sortedarray[(int) answer-1]);
			    	odd = "no";
			    }*/
			}else {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] temp = numberAsString.split("-");
						medianstr1 += String.valueOf((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)+",";
							//xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sum += Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
							medianstr += String.valueOf(Double.parseDouble(ynumberAsString)+sumfre)+",";
							sumfre += Double.parseDouble(ynumberAsString);
							count++;
						
					}
				try {answer = sumfre / 4;}catch(Exception e) {System.out.println(e);}
				medianstr2 += String.valueOf(answer);
			}
		}else if(tool.equals("karl_rel")) {
			if(datatype.equals("rawdata")) {
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      xlist.add(Double.parseDouble(numberAsString));
							count++;
							medianstr += String.valueOf(Math.log10(Double.parseDouble(numberAsString)))+",";
							sum += Math.log10(Double.parseDouble(numberAsString));
					}
				try {mediananswer = sum / count;}catch(Exception e) {System.out.println(e);}
				answer = Math.pow(10, mediananswer);
			}else if(datatype.equals("discretedata")) {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							xsum += Double.parseDouble(numberAsString);
							x2sum += Double.parseDouble(numberAsString)*Double.parseDouble(numberAsString);
							sumfre += Double.parseDouble(ynumberAsString);
							y2sum += Double.parseDouble(ynumberAsString)*Double.parseDouble(ynumberAsString);
							odd += String.valueOf(Double.parseDouble(ynumberAsString)*Double.parseDouble(ynumberAsString))+",";
							medianstr += String.valueOf(Double.parseDouble(numberAsString)*Double.parseDouble(numberAsString))+",";
							medianstr1 += String.valueOf(Double.parseDouble(numberAsString)*Double.parseDouble(ynumberAsString))+",";
							sum += Double.parseDouble(numberAsString)*Double.parseDouble(ynumberAsString);
							count++;
						
					}
				try {mediananswer = sum / sumfre;}catch(Exception e) {System.out.println(e);}
				answer = Math.pow(10, mediananswer);
			}else {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] temp = numberAsString.split("-");
						odd += String.valueOf((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)+",";
							//xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sumfre += Double.parseDouble(ynumberAsString);
							medianstr += String.valueOf(Math.log10(((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)))+",";
							medianstr1 += String.valueOf((Math.log10(((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)))*Double.parseDouble(ynumberAsString))+",";
							sum += (Math.log10(((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)))*Double.parseDouble(ynumberAsString);
							count++;
						
					}
				try {mediananswer = sum / sumfre;}catch(Exception e) {System.out.println(e);}
				answer = Math.pow(10, mediananswer);
			}
		}else if(tool.equals("sd")) {
			if(datatype.equals("rawdata")) {
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      xlist.add(Double.parseDouble(numberAsString));
							count++;
							xsum += Double.parseDouble(numberAsString);
							medianstr += String.valueOf((Double.parseDouble(numberAsString))*(Double.parseDouble(numberAsString)))+",";
							sum += (Double.parseDouble(numberAsString))*(Double.parseDouble(numberAsString));
							x2sum += Double.parseDouble(numberAsString)*Double.parseDouble(numberAsString);
					}
				try {mediananswer = xsum / count;}catch(Exception e) {System.out.println(e);}
			}else if(datatype.equals("discretedata")) {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							xsum += Double.parseDouble(numberAsString);
							x2sum += Double.parseDouble(numberAsString)*Double.parseDouble(numberAsString);
							sumfre += Double.parseDouble(ynumberAsString);
							y2sum += Double.parseDouble(ynumberAsString)*Double.parseDouble(numberAsString);
							odd += String.valueOf(Double.parseDouble(ynumberAsString)*Double.parseDouble(numberAsString))+",";
							medianstr += String.valueOf(Double.parseDouble(numberAsString)*Double.parseDouble(numberAsString))+",";
							medianstr1 += String.valueOf(Double.parseDouble(numberAsString)*Double.parseDouble(numberAsString)*Double.parseDouble(ynumberAsString))+",";
							sum += Double.parseDouble(numberAsString)*Double.parseDouble(numberAsString)*Double.parseDouble(ynumberAsString);
							count++;
						
					}
				try {mediananswer = y2sum / sumfre;}catch(Exception e) {System.out.println(e);}
			}else {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] temp = numberAsString.split("-");
				      medianstr2 += String.valueOf((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)+",";
							//xlist.add(Double.parseDouble(numberAsString));
				      ylist.add(Double.parseDouble(ynumberAsString));
						xsum += ((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
						x2sum += ((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
						sumfre += Double.parseDouble(ynumberAsString);
						y2sum += Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
						odd += String.valueOf(Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2))+",";
						medianstr += String.valueOf(((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2))+",";
						medianstr1 += String.valueOf(((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)*Double.parseDouble(ynumberAsString))+",";
						sum += ((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)*Double.parseDouble(ynumberAsString);
						count++;
						
					}
				try {mediananswer = y2sum / sumfre;}catch(Exception e) {System.out.println(e);}
			}
		}else if(tool.equals("skp")) {
			if(datatype.equals("rawdata")) {
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      xlist.add(Double.parseDouble(numberAsString));
							count++;
							xsum += Double.parseDouble(numberAsString);
							medianstr += String.valueOf((Double.parseDouble(numberAsString))*(Double.parseDouble(numberAsString)))+",";
							sum += (Double.parseDouble(numberAsString))*(Double.parseDouble(numberAsString));
							x2sum += Double.parseDouble(numberAsString)*Double.parseDouble(numberAsString);
					}
				try {mediananswer = xsum / count;}catch(Exception e) {System.out.println(e);}
				z = getRawmode(stringArray);
			}else if(datatype.equals("discretedata")) {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				
				int index1 = 0;
				String temp = "";
				double temp1 = 0.0;
				/*g0a = new String[stringArray.length+2];
				g1a = new String[stringArray.length+2];
				g2a = new String[stringArray.length+2];
				g3a = new String[stringArray.length+2];
				g4a = new String[stringArray.length+2];
				g5a = new String[stringArray.length+2];
				g6a = new String[stringArray.length+2];
				g7a = new String[stringArray.length+2];
				for (int i = 0; i < stringArray.length+2; i++) {
					g0a[i] = "0";
					g1a[i] = "0";
					g2a[i] = "0";
					g3a[i] = "0";
					g4a[i] = "0";
					g5a[i] = "0";
					g6a[i] = "0";
					g7a[i] = "0";
						
					}*/
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] tep = numberAsString.split("-");
				      medianstr2 += String.valueOf((Double.parseDouble(tep[1])+Double.parseDouble(tep[0]))/2)+",";
							xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							xsum += Double.parseDouble(numberAsString);
							x2sum += Double.parseDouble(numberAsString)*Double.parseDouble(numberAsString);
							sumfre += Double.parseDouble(ynumberAsString);
							y2sum += Double.parseDouble(ynumberAsString)*Double.parseDouble(numberAsString);
							odd += String.valueOf(Double.parseDouble(ynumberAsString)*Double.parseDouble(numberAsString))+",";
							medianstr += String.valueOf(Double.parseDouble(numberAsString)*Double.parseDouble(numberAsString))+",";
							medianstr1 += String.valueOf(Double.parseDouble(numberAsString)*Double.parseDouble(numberAsString)*Double.parseDouble(ynumberAsString))+",";
							sum += Double.parseDouble(numberAsString)*Double.parseDouble(numberAsString)*Double.parseDouble(ynumberAsString);
							count++;
							if(temp1 < Double.parseDouble(ynumberAsString)) {
								temp1 = Double.parseDouble(ynumberAsString);
								index1 = i;
							}
							
						
					}
				/*g0a [0] = "Col.No";
				g1a [0] = "1";
				g2a [0] = "2";
				g3a [0] = "3";
				g4a [0] = "4";
				g5a [0] = "5";
				g6a [0] = "6";
				g7a [0] = "Total";
				for (int j = 0; j < stringArray.length; j++) {
					String numberAsString = stringArray[j];
					System.out.println(numberAsString);
					String ynumberAsString = ystringArray[j];
					g0a [j+1] = numberAsString;
					g1a [j+1] = "0";
					g2a [j+1] = "0";
					g3a [j+1] = "0";
					g4a [j+1] = "0";
					g5a [j+1] = "0";
					g6a [j+1] = "0";
					if((Double.valueOf(ystringArray[index1]) == Double.valueOf(ynumberAsString) && j != index1) || Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+1)|| Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+2)) {
						odd = "yes";
						
					}
					System.out.println(ystringArray[index1]+" == "+ ynumberAsString +" && "+String.valueOf(j) +"!="+ String.valueOf(index1)+" ||"+ystringArray[index1]+" == "+String.valueOf(Double.valueOf(ynumberAsString)+1)+"|| "+ystringArray[index1]+" == "+String.valueOf(Double.valueOf(ynumberAsString)+2));
					System.out.println((Double.valueOf(ystringArray[index1]) == Double.valueOf(ynumberAsString) && j != index1) || Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+1)|| Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+2));
				}
				if(odd.equals("yes")) {
					
					g1a[index1+1] = "1";
					g1a[ystringArray.length+1] = "1";
					int i0 = 0; int i1 = 1; int i2 = 2;
					double maxvalue = 0;
					int tempi0 = 0;int tempi1 = 0;int tempi2 = 0;
					for (int i = 0; i < (ystringArray.length-ystringArray.length%2)/2; i++) {
						g2 += ystringArray[i0]+"+"+ystringArray[i1]+"="+String.valueOf(Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1]))+",";
						
						
						if(maxvalue < Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1])) {
							tempi0 = i0;tempi1 = i1;
						}
						i0 += 2;i1 += 2;
						if(i == ((ystringArray.length-ystringArray.length%2)/2)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1));
							g2a[tempi0-3] = "1";
							g2a[tempi1-3] = "1";
							i0 = 0; i1 = 1;
						}
					}
					for (int i = 0; i < ((ystringArray.length)-ystringArray.length%2)/2; i++) {
						g3 += ystringArray[i0+1]+"+"+ystringArray[i1+1]+"="+String.valueOf(Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1]))+",";
						
						if(maxvalue < Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1])) {
							tempi0 = i0+1;tempi1 = i1+1;
						}
						i0 += 2;i1 += 2;
						if(i == (((ystringArray.length)-ystringArray.length%2)/2)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1));
							g3a[tempi0-3] = "1";
							g3a[tempi1-3] = "1";
							i0 = 0; i1 = 1;
						}
					}
					System.out.println(g2+" "+g3);
					System.out.println(String.valueOf(i0)+" "+String.valueOf(i1)+" "+String.valueOf(i2));
					for (int i = 0; i < (ystringArray.length-ystringArray.length%3)/3; i++) {
						System.out.println(String.valueOf(i0)+" "+String.valueOf(i1)+" "+String.valueOf(i2));
						g4 += ystringArray[i0]+"+"+ystringArray[i1]+"+"+ystringArray[i2]+"="+String.valueOf(Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1])+Double.valueOf(ystringArray[i2]))+",";
						
						if(maxvalue < Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1])+Double.valueOf(ystringArray[i2])) {
							tempi0 = i0;tempi1 = i1;tempi2 = i2;
						}
						i0 += 3;i1 += 3;i2 += 3;
						if(i == ((ystringArray.length-ystringArray.length%3)/3)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1)+"   "+String.valueOf(tempi2+1));
							g4a[tempi0-2] = "1";
							g4a[tempi1-2] = "1";
							g4a[tempi2-2] = "1";
							i0 = 0; i1 = 1; i2 = 2;
						}
					}
					for (int i = 0; i < ((ystringArray.length-1)-ystringArray.length%3)/3; i++) {
						g5 += ystringArray[i0+1]+"+"+ystringArray[i1+1]+"+"+ystringArray[i2+1]+"="+String.valueOf(Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1])+Double.valueOf(ystringArray[i2+1]))+",";
						if(maxvalue < Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1])+Double.valueOf(ystringArray[i2+1])) {
							tempi0 = i0+1;tempi1 = i1+1;tempi2 = i2+1;
						}
						i0 += 3;i1 += 3;i2 += 3;
						if(i == (((ystringArray.length-1)-ystringArray.length%3)/3)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1)+"   "+String.valueOf(tempi2+1));
							g5a[tempi0-2] = "1";
							g5a[tempi1-2] = "1";
							g5a[tempi2-2] = "1";
							i0 = 0; i1 = 1; i2 = 2;
						}
					}
					for (int i = 0; i < ((ystringArray.length-1)-ystringArray.length%3)/3; i++) {
						g6 += ystringArray[i0+2]+"+"+ystringArray[i1+2]+"+"+ystringArray[i2+2]+"="+String.valueOf(Double.valueOf(ystringArray[i0+2])+Double.valueOf(ystringArray[i1+2])+Double.valueOf(ystringArray[i2+2]))+",";
						
						if(maxvalue < Double.valueOf(ystringArray[i0+2])+Double.valueOf(ystringArray[i1+2])+Double.valueOf(ystringArray[i2+2])) {
							tempi0 = i0+2;tempi1 = i1+2;tempi2 = i2+2;
						}
						i0 += 3;i1 += 3;i2 += 3;
						if(i == (((stringArray.length-1)-stringArray.length%3)/3)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1)+"   "+String.valueOf(tempi2+1));
							g6a[tempi0-2] = "1";
							g6a[tempi1-2] = "1";
							g6a[tempi2-2] = "1";
							
						}
					}
					System.out.println(g4+" "+g5+" "+g6);
					g2a[ystringArray.length+1] = "2";
					g3a[ystringArray.length+1] = "2";
					g4a[ystringArray.length+1] = "3";
					g5a[ystringArray.length+1] = "3";
					g6a[ystringArray.length+1] = "3";
					for(int i=0; i < ystringArray.length; i++) {
						g7a[i+1] = String.valueOf(Double.valueOf(g1a[i+1])+Double.valueOf(g2a[i+1])+Double.valueOf(g3a[i+1])+Double.valueOf(g4a[i+1])+Double.valueOf(g5a[i+1])+Double.valueOf(g6a[i+1]));
						
					}
					g7a[ystringArray.length+1] = "14";
					g0a[ystringArray.length+1] = "Total";
				}
				double temp2 = 0.0;
				for (int i = 0; i < stringArray.length; i++) {
				      String g7astring = g7a[i+1];
							
							if(temp2 < Double.parseDouble(g7astring)) {
								temp2 = Double.parseDouble(g7astring);
								index1 = i;
							}
						
					}*/
				System.out.println(String.valueOf(index1));
				try {mediananswer = y2sum / sumfre;}catch(Exception e) {System.out.println(e);}
				z = stringArray[index1];
			}else {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				double temp1 = 0.0;
				int index1 = 0;
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] temp = numberAsString.split("-");
				      medianstr2 += String.valueOf((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)+",";
							//xlist.add(Double.parseDouble(numberAsString));
				      ylist.add(Double.parseDouble(ynumberAsString));
						xsum += ((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
						x2sum += ((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
						sumfre += Double.parseDouble(ynumberAsString);
						y2sum += Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
						odd += String.valueOf(Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2))+",";
						medianstr += String.valueOf(((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2))+",";
						medianstr1 += String.valueOf(((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)*Double.parseDouble(ynumberAsString))+",";
						sum += ((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)*Double.parseDouble(ynumberAsString);
						count++;
						if(temp1 < Double.parseDouble(ynumberAsString)) {
							temp1 = Double.parseDouble(ynumberAsString);
							index1 = i;
						}
						
					}
				/*g0a [0] = "Col.No";
				g1a [0] = "1";
				g2a [0] = "2";
				g3a [0] = "3";
				g4a [0] = "4";
				g5a [0] = "5";
				g6a [0] = "6";
				g7a [0] = "Total";
				for (int j = 0; j < stringArray.length; j++) {
					String numberAsString = stringArray[j];
					System.out.println(numberAsString);
					String ynumberAsString = ystringArray[j];
					g0a [j+1] = numberAsString;
					g1a [j+1] = "0";
					g2a [j+1] = "0";
					g3a [j+1] = "0";
					g4a [j+1] = "0";
					g5a [j+1] = "0";
					g6a [j+1] = "0";
					if((Double.valueOf(ystringArray[index1]) == Double.valueOf(ynumberAsString) && j != index1) || Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+1)|| Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+2)) {
						odd = "yes";
						
					}
					System.out.println(ystringArray[index1]+" == "+ ynumberAsString +" && "+String.valueOf(j) +"!="+ String.valueOf(index1)+" ||"+ystringArray[index1]+" == "+String.valueOf(Double.valueOf(ynumberAsString)+1)+"|| "+ystringArray[index1]+" == "+String.valueOf(Double.valueOf(ynumberAsString)+2));
					System.out.println((Double.valueOf(ystringArray[index1]) == Double.valueOf(ynumberAsString) && j != index1) || Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+1)|| Double.valueOf(ystringArray[index1]) == (Double.valueOf(ynumberAsString)+2));
				}
				if(odd.equals("yes")) {
					
					g1a[index1+1] = "1";
					g1a[ystringArray.length+1] = "1";
					int i0 = 0; int i1 = 1; int i2 = 2;
					double maxvalue = 0;
					int tempi0 = 0;int tempi1 = 0;int tempi2 = 0;
					for (int i = 0; i < (ystringArray.length-ystringArray.length%2)/2; i++) {
						g2 += ystringArray[i0]+"+"+ystringArray[i1]+"="+String.valueOf(Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1]))+",";
						
						
						if(maxvalue < Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1])) {
							tempi0 = i0;tempi1 = i1;
						}
						i0 += 2;i1 += 2;
						if(i == ((ystringArray.length-ystringArray.length%2)/2)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1));
							g2a[tempi0-3] = "1";
							g2a[tempi1-3] = "1";
							i0 = 0; i1 = 1;
						}
					}
					for (int i = 0; i < ((ystringArray.length)-ystringArray.length%2)/2; i++) {
						g3 += ystringArray[i0+1]+"+"+ystringArray[i1+1]+"="+String.valueOf(Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1]))+",";
						
						if(maxvalue < Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1])) {
							tempi0 = i0+1;tempi1 = i1+1;
						}
						i0 += 2;i1 += 2;
						if(i == (((ystringArray.length)-ystringArray.length%2)/2)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1));
							g3a[tempi0-5] = "1";
							g3a[tempi1-5] = "1";
							i0 = 0; i1 = 1;
						}
					}
					System.out.println(g2+" "+g3);
					System.out.println(String.valueOf(i0)+" "+String.valueOf(i1)+" "+String.valueOf(i2));
					for (int i = 0; i < (ystringArray.length-ystringArray.length%3)/3; i++) {
						System.out.println(String.valueOf(i0)+" "+String.valueOf(i1)+" "+String.valueOf(i2));
						g4 += ystringArray[i0]+"+"+ystringArray[i1]+"+"+ystringArray[i2]+"="+String.valueOf(Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1])+Double.valueOf(ystringArray[i2]))+",";
						
						if(maxvalue < Double.valueOf(ystringArray[i0])+Double.valueOf(ystringArray[i1])+Double.valueOf(ystringArray[i2])) {
							tempi0 = i0;tempi1 = i1;tempi2 = i2;
						}
						i0 += 3;i1 += 3;i2 += 3;
						if(i == ((ystringArray.length-ystringArray.length%3)/3)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1)+"   "+String.valueOf(tempi2+1));
							g4a[tempi0-5] = "1";
							g4a[tempi1-5] = "1";
							g4a[tempi2-5] = "1";
							i0 = 0; i1 = 1; i2 = 2;
						}
					}
					for (int i = 0; i < ((ystringArray.length-1)-ystringArray.length%3)/3; i++) {
						g5 += ystringArray[i0+1]+"+"+ystringArray[i1+1]+"+"+ystringArray[i2+1]+"="+String.valueOf(Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1])+Double.valueOf(ystringArray[i2+1]))+",";
						if(maxvalue < Double.valueOf(ystringArray[i0+1])+Double.valueOf(ystringArray[i1+1])+Double.valueOf(ystringArray[i2+1])) {
							tempi0 = i0+1;tempi1 = i1+1;tempi2 = i2+1;
						}
						i0 += 3;i1 += 3;i2 += 3;
						if(i == (((ystringArray.length-1)-ystringArray.length%3)/3)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1)+"   "+String.valueOf(tempi2+1));
							g5a[tempi0-2] = "1";
							g5a[tempi1-2] = "1";
							g5a[tempi2-2] = "1";
							i0 = 0; i1 = 1; i2 = 2;
						}
					}
					for (int i = 0; i < ((ystringArray.length-1)-ystringArray.length%3)/3; i++) {
						g6 += ystringArray[i0+2]+"+"+ystringArray[i1+2]+"+"+ystringArray[i2+2]+"="+String.valueOf(Double.valueOf(ystringArray[i0+2])+Double.valueOf(ystringArray[i1+2])+Double.valueOf(ystringArray[i2+2]))+",";
						
						if(maxvalue < Double.valueOf(ystringArray[i0+2])+Double.valueOf(ystringArray[i1+2])+Double.valueOf(ystringArray[i2+2])) {
							tempi0 = i0+2;tempi1 = i1+2;tempi2 = i2+2;
						}
						i0 += 3;i1 += 3;i2 += 3;
						if(i == (((stringArray.length-1)-stringArray.length%3)/3)-1) {
							System.out.println(String.valueOf(tempi0+1)+"   "+String.valueOf(tempi1+1)+"   "+String.valueOf(tempi2+1));
							g6a[tempi0-2] = "1";
							g6a[tempi1-2] = "1";
							g6a[tempi2-2] = "1";
							
						}
					}
					System.out.println(g4+" "+g5+" "+g6);
					g2a[ystringArray.length+1] = "2";
					g3a[ystringArray.length+1] = "2";
					g4a[ystringArray.length+1] = "3";
					g5a[ystringArray.length+1] = "3";
					g6a[ystringArray.length+1] = "3";
					for(int i=0; i < ystringArray.length; i++) {
						g7a[i+1] = String.valueOf(Double.valueOf(g1a[i+1])+Double.valueOf(g2a[i+1])+Double.valueOf(g3a[i+1])+Double.valueOf(g4a[i+1])+Double.valueOf(g5a[i+1])+Double.valueOf(g6a[i+1]));
						
					}
					g7a[ystringArray.length+1] = "14";
					g0a[ystringArray.length+1] = "Total";
				}
				double temp2 = 0.0;
				for (int i = 0; i < stringArray.length; i++) {
				      String g7astring = g7a[i+1];
							
							if(temp2 < Double.parseDouble(g7astring)) {
								temp2 = Double.parseDouble(g7astring);
								index1 = i;
							}
						
					}
				System.out.println(String.valueOf(index1));*/
				try {answer = 9%2;}catch(Exception e) {System.out.println(e);}
				String s0 = stringArray[index1];
				String[] l1 = s0.split("-");
				l = l1[0];
				f1 = ystringArray[index1];
				f0 = ystringArray[index1-1];
				f2 = ystringArray[index1+1];
				i = String.valueOf(Integer.valueOf(l1[1])-Integer.valueOf(l1[0]));
				
				/*ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] temp = numberAsString.split("-");
						medianstr1 += String.valueOf((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)+",";
							//xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sumfre += Double.parseDouble(ynumberAsString);
							sum += Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
							medianstr += String.valueOf(Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2))+",";
							count++;
						
					}
				try {answer = sum / sumfre;}catch(Exception e) {System.out.println(e);}*/
			
				try {mediananswer = y2sum / sumfre;}catch(Exception e) {System.out.println(e);}
			}
		
	    
		}else if(tool.equals("skbow")) {
			if(datatype.equals("rawdata")) {
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							count++;
						
					}
				sum = count+1;
				sortedarray = x.split(",");
				sortedarray = getSortedarray(sortedarray);
			    try {answer = sum / 4;}catch(Exception e) {System.out.println(e);}
			    if((sum%4)!= 0) {
			    	medianstr = "("+String.valueOf(answer-0.5)+"th value+"+String.valueOf(answer+0.5)+"th value)/4";
			    	medianstr1 = "("+String.valueOf(sortedarray[(int) (answer-0.5)-1]+"+"+String.valueOf(sortedarray[(int) (answer+0.5)-1]))+")/2";
			    	g2 = "("+String.valueOf(3*answer-0.5)+"th value+"+String.valueOf(3*answer+0.5)+"th value)/2";
			    	g3 = "("+String.valueOf(sortedarray[(int) (3*answer-0.5)-1]+"+"+String.valueOf(sortedarray[(int) (3*answer+0.5)-1]))+")/2";
			    	mediananswer = ((Double.parseDouble(sortedarray[(int) ((answer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((answer+0.5)-1)]))/2);
			    	f1 = String.valueOf((Double.parseDouble(sortedarray[(int) ((3*answer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((3*answer+0.5)-1)]))/2);
			    	medianpos = (int) (Double.parseDouble(sortedarray[(int) ((answer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((answer+0.5)-1)]));
			    	q1 = (int) (Double.parseDouble(sortedarray[(int) ((3*answer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((3*answer+0.5)-1)]));
			    	odd = "yes";
			    }else {
			    	mediananswer = Integer.parseInt(sortedarray[(int) answer-1]);
			    	f1 = String.valueOf(Integer.parseInt(sortedarray[(int) (3*answer)-1]));
			    	odd = "no";
			    }
			    
			    try {setBanswer(sum / 2);}catch(Exception e) {System.out.println(e);}
			    if((sum%2)!= 0) {
			    	setBmedianpos((int) ((banswer-0.5)+(banswer+0.5))/2);
			    	setBmedianstr("("+String.valueOf(banswer-0.5)+"th value+"+String.valueOf(banswer+0.5)+"th value)/2");
			    	setBmedianstr1("("+String.valueOf(sortedarray[(int) (banswer-0.5)-1]+"+"+String.valueOf(sortedarray[(int) (banswer+0.5)-1]))+")/2");
			    	setBmediananswer(((Double.parseDouble(sortedarray[(int) ((banswer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((banswer+0.5)-1)]))/2));
			    	setBodd("yes");
			    }else {
			    	setBmediananswer(Integer.parseInt(sortedarray[(int) banswer-1]));
			    	setBodd("no");
			    }
			    
			}else if(datatype.equals("discretedata")) {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				// medianstr += String.valueOf(Double.parseDouble(ystringArray[0]));
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
							xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							medianstr += String.valueOf(Double.parseDouble(ynumberAsString)+sumfre)+",";
							sumfre += Double.parseDouble(ynumberAsString);
							count++;
						
					}
				sum = sumfre+1;
				/*sortedarray = x.split(",");
				sortedarray = getSortedarray(sortedarray);*/
			    try {answer = sum / 4;}catch(Exception e) {System.out.println(e);}
			    medianstr1 += String.valueOf(answer);
			    /*if((sum%2)!= 0) {
			    	medianpos = (int) ((answer-0.5)+(answer+0.5))/2;
			    	medianstr = "("+String.valueOf(answer-0.5)+"th value+"+String.valueOf(answer+0.5)+"th value)/2";
			    	medianstr1 = "("+String.valueOf(sortedarray[(int) (answer-0.5)-1]+"+"+String.valueOf(sortedarray[(int) (answer+0.5)-1]))+")/2";
			    	mediananswer = ((Double.parseDouble(sortedarray[(int) ((answer-0.5)-1)])+Double.parseDouble(sortedarray[(int) ((answer+0.5)-1)]))/2);
			    	odd = "yes";
			    }else {
			    	mediananswer = Integer.parseInt(sortedarray[(int) answer-1]);
			    	odd = "no";
			    }*/
			    
			    try {banswer = sum / 2;}catch(Exception e) {System.out.println(e);}
			    bmedianstr1 += String.valueOf(banswer);
			    
			}else {
				ylist = new ArrayList<Double>();
				fxlist = new ArrayList<Double>();
				String[] ystringArray = y.split(",");
				for (int i = 0; i < stringArray.length; i++) {
				      String numberAsString = stringArray[i];
				      String ynumberAsString = ystringArray[i];
				      String[] temp = numberAsString.split("-");
						medianstr1 += String.valueOf((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2)+",";
							//xlist.add(Double.parseDouble(numberAsString));
							ylist.add(Double.parseDouble(ynumberAsString));
							sum += Double.parseDouble(ynumberAsString)*((Double.parseDouble(temp[1])+Double.parseDouble(temp[0]))/2);
							medianstr += String.valueOf(Double.parseDouble(ynumberAsString)+sumfre)+",";
							sumfre += Double.parseDouble(ynumberAsString);
							count++;
						
					}
				try {answer = sumfre / 4;}catch(Exception e) {System.out.println(e);}
				medianstr2 += String.valueOf(answer);
			}
		}
		return datatype;
	}
	public String[] getSortedarray(String[] sortedarray) {
		String temp = "";
		for (int i = 0; i < sortedarray.length; i++) 
        {
            for (int j = i + 1; j < sortedarray.length; j++) 
            {
                if (Double.parseDouble(sortedarray[i]) > Double.parseDouble(sortedarray[j])) 
                {
                    temp = sortedarray[i];
                    sortedarray[i] = sortedarray[j];
                    sortedarray[j] = temp;
                }
            }
        }
		return sortedarray;
	}
	public String getRawmode(String[] stringArray) {
		String result = "";
		int count = 0;
		for(int i = 0 ; i < stringArray.length; i++) {
			int count1 = 0;
			String temp = stringArray[i];
			for(int j = 0 ; j < stringArray.length; j++) {
				if(temp.equals(stringArray[j])) {
					count1 ++;
				}
			}
			if(count1 > count) {
				count = count1;
				result = temp;
			}else if(count1 == count) {
				if(result.equals(temp)) {
					result = temp;
				}else if(!result.equals(temp)) {
					result = "no mode";
				}
			}
		}
		
		return result;
	}
	public String getDatatype() {
		return datatype;
	}
	public void setDatatype(String datatype) {
		this.datatype = datatype;
	}
	public String getTool() {
		return tool;
	}
	public void setTool(String tool) {
		this.tool = tool;
	}
	public String getX() {
		return x;
	}
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	public void setY(String y) {
		this.y = y;
	}
	public double getSum() {
		return sum;
	}
	public void setSum(double sum) {
		this.sum = sum;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public List<Double> getXlist() {
		return xlist;
	}
	public double getAnswer() {
		return answer;
	}
	public void setAnswer(double answer) {
		this.answer = answer;
	}
	public double getMediananswer() {
		return mediananswer;
	}
	public void setMediananswer(double mediananswer) {
		this.mediananswer = mediananswer;
	}
	public int getMedianpos() {
		return medianpos;
	}
	public void setMedianpos(int medianpos) {
		this.medianpos = medianpos;
	}
	public String getMedianstr() {
		return medianstr;
	}
	public void setMedianstr(String medianstr) {
		this.medianstr = medianstr;
	}
	public String[] getSortedarray() {
		return sortedarray;
	}
	public void setSortedarray(String[] sortedarray) {
		this.sortedarray = sortedarray;
	}
	public String getOdd() {
		return odd;
	}
	public void setOdd(String odd) {
		this.odd = odd;
	}
	public String getMedianstr1() {
		return medianstr1;
	}
	public void setMedianstr1(String medianstr1) {
		this.medianstr1 = medianstr1;
	}
	public List<Double> getLoglist() {
		return loglist;
	}
	public void setLoglist(List<Double> loglist) {
		this.loglist = loglist;
	}
	public List<Double> getYlist() {
		return ylist;
	}
	public void setYlist(List<Double> ylist) {
		this.ylist = ylist;
	}
	public double getSumfre() {
		return sumfre;
	}
	public void setSumfre(double sumfre) {
		this.sumfre = sumfre;
	}
	public List<Double> getFxlist() {
		return fxlist;
	}
	public void setFxlist(List<Double> fxlist) {
		this.fxlist = fxlist;
	}
	public double getY2sum() {
		return y2sum;
	}
	public void setY2sum(double y2sum) {
		this.y2sum = y2sum;
	}
	public double getX2sum() {
		return x2sum;
	}
	public void setX2sum(double x2sum) {
		this.x2sum = x2sum;
	}
	public double getXsum() {
		return xsum;
	}
	public void setXsum(double xsum) {
		this.xsum = xsum;
	}
	public String getMedianstr2() {
		return medianstr2;
	}
	public void setMedianstr2(String medianstr2) {
		this.medianstr2 = medianstr2;
	}
	public String getG6() {
		return g6;
	}
	public void setG6(String g6) {
		this.g6 = g6;
	}
	public String getG4() {
		return g4;
	}
	public void setG4(String g4) {
		this.g4 = g4;
	}
	public String getG5() {
		return g5;
	}
	public void setG5(String g5) {
		this.g5 = g5;
	}
	public String getG3() {
		return g3;
	}
	public void setG3(String g3) {
		this.g3 = g3;
	}
	public String getG2() {
		return g2;
	}
	public void setG2(String g2) {
		this.g2 = g2;
	}
	public String[] getG1a() {
		return g1a;
	}
	public void setG1a(String[] g1a) {
		this.g1a = g1a;
	}
	public String[] getG2a() {
		return g2a;
	}
	public void setG2a(String[] g2a) {
		this.g2a = g2a;
	}
	public String[] getG3a() {
		return g3a;
	}
	public void setG3a(String[] g3a) {
		this.g3a = g3a;
	}
	public String[] getG4a() {
		return g4a;
	}
	public void setG4a(String[] g4a) {
		this.g4a = g4a;
	}
	public String[] getG5a() {
		return g5a;
	}
	public void setG5a(String[] g5a) {
		this.g5a = g5a;
	}
	public String[] getG6a() {
		return g6a;
	}
	public void setG6a(String[] g6a) {
		this.g6a = g6a;
	}
	public String[] getG7a() {
		return g7a;
	}
	public void setG7a(String[] g7a) {
		this.g7a = g7a;
	}
	public String[] getG0a() {
		return g0a;
	}
	public void setG0a(String[] g0a) {
		this.g0a = g0a;
	}
	public String getL() {
		return l;
	}
	public void setL(String l) {
		this.l = l;
	}
	public String getF0() {
		return f0;
	}
	public void setF0(String f0) {
		this.f0 = f0;
	}
	public String getF2() {
		return f2;
	}
	public void setF2(String f2) {
		this.f2 = f2;
	}
	public String getI() {
		return i;
	}
	public void setI(String i) {
		this.i = i;
	}
	public String getF1() {
		return f1;
	}
	public void setF1(String f1) {
		this.f1 = f1;
	}
	public String getZ() {
		return z;
	}
	public void setZ(String z) {
		this.z = z;
	}
	public double getQ1() {
		return q1;
	}
	public void setQ1(double q1) {
		this.q1 = q1;
	}
	public double getBanswer() {
		return banswer;
	}
	public void setBanswer(double banswer) {
		this.banswer = banswer;
	}
	public int getBmedianpos() {
		return bmedianpos;
	}
	public void setBmedianpos(int bmedianpos) {
		this.bmedianpos = bmedianpos;
	}
	public String getBmedianstr() {
		return bmedianstr;
	}
	public void setBmedianstr(String bmedianstr) {
		this.bmedianstr = bmedianstr;
	}
	public String getBmedianstr1() {
		return bmedianstr1;
	}
	public void setBmedianstr1(String bmedianstr1) {
		this.bmedianstr1 = bmedianstr1;
	}
	public double getBmediananswer() {
		return bmediananswer;
	}
	public void setBmediananswer(double bmediananswer) {
		this.bmediananswer = bmediananswer;
	}
	public String getBodd() {
		return bodd;
	}
	public void setBodd(String bodd) {
		this.bodd = bodd;
	}
}
