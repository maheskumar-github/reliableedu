/**
 * 
 */
package org.descripitive.statisticsnewui.welcome;

/**
 * @author maheskumar
 *
 */
public class WelcomeAction {
	public String execute()
	{
		return "success";
	}
}
